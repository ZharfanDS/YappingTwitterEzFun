import tweepy
from google import genai
import schedule
import time
import datetime
import random
import os
from dotenv import load_dotenv # Tambahan

# --- 0. LOAD KREDENSIAL DARI .ENV ---
load_dotenv()

TWITTER_KEYS = {
    "consumer_key": os.getenv("TWITTER_CONSUMER_KEY"),
    "consumer_secret": os.getenv("TWITTER_CONSUMER_SECRET"),
    "access_token": os.getenv("TWITTER_ACCESS_TOKEN"),
    "access_token_secret": os.getenv("TWITTER_ACCESS_TOKEN_SECRET")
}

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# --- 1. INISIALISASI CLIENT ---
client = tweepy.Client(
    consumer_key=TWITTER_KEYS["consumer_key"],
    consumer_secret=TWITTER_KEYS["consumer_secret"],
    access_token=TWITTER_KEYS["access_token"],
    access_token_secret=TWITTER_KEYS["access_token_secret"]
)

ai_client = genai.Client(api_key=GEMINI_API_KEY)

# ... (sisa kode fungsi generate_yapping dan kirim_tweet tetap sama) ...

def generate_yapping():
    """Membuat konten tweet berkualitas"""
    # Menentukan kategori konten agar tidak membosankan
    topics = [
        "product improvement suggestion for @easydotfun",
        "witty reaction to trending crypto news and how it relates to @easydotfun",
        "breakdown of a feature that makes @easydotfun better than other platforms",
        "insightful takes on the current vibe of the @easydotfun leaderboard",
        "creative 'spicy' take on why the community is so strong"
    ]
    
    selected_topic = random.choice(topics)
    
    prompt = (
        f"Role: You are a creative member of the @easydotfun 'Viber' community. "
        f"Task: Write a high-quality Twitter post about: {selected_topic}. "
        "Guidelines: "
        "- Avoid low-effort phrases like 'LFG', 'I'm in', or 'Great project'. "
        "- Use a mix of insightful, witty, and casual 'crypto degen' language. "
        "- Keep it under 240 characters and tag @easydotfun. "
        "- Tone: Positive, creative, and slightly spicy but respectful. "
        "- No excessive hashtags. Focus on spreading the 'vibe'. "
        "Language: English."
    )
    
    try:
        response = ai_client.models.generate_content(
            model='gemini-2.0-flash',
            contents=prompt
        )
        return response.text.strip()
    except Exception as e:
        print(f"[{datetime.datetime.now()}] AI Error: {e}")
        return "Deep diving into @easydotfun features today. The UI/UX is actually next level compared to what's out there. 📈✨"

def kirim_tweet():
    """Eksekusi pengiriman tweet dengan Random Delay agar aman dari suspend"""
    delay_detik = random.randint(60, 900)
    menit = delay_detik // 60
    print(f"[{datetime.datetime.now()}] Jadwal tercapai. Menunggu {menit} menit agar terlihat natural...")
    time.sleep(delay_detik)

    print(f"[{datetime.datetime.now()}] Memulai proses kirim tweet...")
    pesan = generate_yapping()
    pesan_bersih = " ".join(pesan.split())
    
    try:
        client.create_tweet(text=pesan_bersih, user_auth=True)
        print(f"[{datetime.datetime.now()}] BERHASIL POSTING: {pesan_bersih}")
    except Exception as e:
        print(f"[{datetime.datetime.now()}] GAGAL: {e}")

# --- 3. PENJADWALAN ---
schedule.every().day.at("07:00").do(kirim_tweet)
schedule.every().day.at("17:00").do(kirim_tweet)

print("="*50)
print("Bot Auto Yapping @easydotfun ACTIVE (with .env security)")
print("Jadwal: 07:00 & 17:00 WIB")
print("="*50)

while True:
    schedule.run_pending()
    time.sleep(30)